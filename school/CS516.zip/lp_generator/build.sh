mingw32-make clean >/dev/null 2>&1
g++ -std=c++11 -g main.cpp KDG.cpp Parser.cpp -o lp_generator 
./lp_generator --budget 99 --xml ../example_output/smallKDG.xml --app smallKDG
